<?php return array (
  'orders' => 'App\\Http\\Livewire\\Orders',
);