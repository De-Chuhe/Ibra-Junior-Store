<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderReceipt extends Model
{
    // Assuming each order receipt belongs to a product
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    // Assuming each order receipt belongs to an order
    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
