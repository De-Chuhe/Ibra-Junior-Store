<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Product;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;

class Orders extends Component
{
    public $product_code; // Same as product_id
    public $product;      // Product object
    public $quantity = 1; // Default quantity
    public $message;      // Message for error or success
    public $productInCart; // Cart items

    public function mount(){
        // Fetch cart items
        $this->productInCart = Cart::where('user_id', Auth::id())->get();
    }

    // Fetch product by product_code (which is the same as product_id)
    public function fetchProduct(){
        // Validate input to ensure product_code is required and exists in products table as id
        $this->validate([
            'product_code' => 'required|exists:products,id',
        ]);

        // Find the product based on product_code (id)
        $this->product = Product::find($this->product_code);

        if ($this->product) {
            $this->message = 'Product Found: ' . $this->product->product_name;
        } else {
            $this->message = 'Product Not Found. Please check the product code.';
        }
    }

    public function Inserttocart(){
        // Ensure a product is selected first
        if (!$this->product) {
            $this->message = 'Please search for a product first.';
            return;
        }

        // Check if the product already exists in the cart
        $cartProduct = Cart::where('product_id', $this->product->id)
                           ->where('user_id', Auth::id())
                           ->first();

        if ($cartProduct) {
            // Update the quantity of the product in the cart
            $cartProduct->product_qty += $this->quantity;
            $cartProduct->save();
            $this->message = 'Quantity of product ' . $this->product->product_name . ' updated successfully.';
        } else {
            // Add the product to the cart
            Cart::create([
                'product_id' => $this->product->id,
                'product_qty' => $this->quantity, // Add the entered quantity
                'product_price' => $this->product->price,
                'user_id' => Auth::id(),
            ]);
            $this->message = 'Product ' . $this->product->product_name . ' added to cart.';
        }

        // Clear input fields after adding to the cart
        $this->resetForm();

        // Refresh cart items
        $this->productInCart = Cart::where('user_id', Auth::id())->get();
    }

    // Reset form fields after adding to cart
    public function resetForm(){
        $this->product_code = '';
        $this->quantity = 1; // Reset quantity to 1
        $this->product = null;
    }

    public function render()
    {
        return view('livewire.orders', [
            'product' => $this->product,         // Pass the selected product to the view
            'productInCart' => $this->productInCart, // Pass cart data to the view
            'message' => $this->message,         // Pass message to the view
        ]);
    }
}
