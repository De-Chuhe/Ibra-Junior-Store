<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Order;
use App\Models\Order_Detail;
use Illuminate\Http\Request;

class OrderDetailController extends Controller
{
    public function index()
    {
        $products = Product::all();
        $orders = Order::all();
        return view('orders.index', ['products' => $products, 'orders' => $orders]);
    }

    // Other methods...
}
