<?php
namespace App\Http\Controllers;

use App\Models\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    public function store(Request $request){
          // Validate the request
          $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_phone' => 'required|string|max:20',
            'products' => 'required|array',
            'products.*.unitprice' => 'required|numeric',
            'products.*.quantity' => 'required|integer',
            'products.*.discount' => 'nullable|numeric',
            'products.*.amount' => 'required|numeric',
            'balance' => 'required|numeric',
            'paid_amount' => 'required|numeric',
            'payment_method' => 'required|string',
        ]);

        $order_id = null; // Initialize $order_id

        DB::transaction(function() use ($request, &$order_id) {
            // Create Order
            $order = new Order();
            $order->name = $request->customer_name;
            $order->phone = $request->customer_phone;
            $order->save();
            $order_id = $order->id;

            // Create Order Details
            foreach($request->products as $product) {
                $order_detail = new Order_Detail();
                $order_detail->order_id = $order_id;
                $order_detail->unitprice = $product['unitprice'];
                $order_detail->quantity = $product['quantity'];
                $order_detail->discount = $product['discount'];
                $order_detail->amount = $product['amount'];
                $order_detail->save();
            }

            // Create Transaction
            $transaction = new Transaction();
            $transaction->order_id = $order_id;
            $transaction->user_id = auth()->user()->id;
            $transaction->balance = $request->balance;
            $transaction->paid_amount = $request->paid_amount;
            $transaction->payment_method = $request->payment_method;
            $transaction->transac_amount = $request->amount;
            $transaction->transac_date = now();
            $transaction->save();
        });

        // Retrieve data for view
        $products = Product::all();
        $order_details = Order_Detail::where('order_id', $order_id)->get();
        $orderedBy = Order::where('id', $order_id)->get();

        return view('orders.index', [
            'products' => $products,
            'order_details' => $order_details,
            'customer_orders' => $orderedBy
        ]);
    }
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'quantity' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        try {
            $cartItem = Cart::findOrFail($id);
            $cartItem->product_qty = $request->input('quantity');
            $cartItem->save();

            return redirect()->back()->with('message', 'Cart updated successfully!');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['Cart item not found.']);
        }
    }

    public function delete($id)
    {
        try {
            $cartItem = Cart::findOrFail($id);
            $cartItem->delete();

            return redirect()->back()->with('message', 'Item removed from cart.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['Cart item not found.']);
        }
    }

    public function checkout()
    {
        // Implement checkout logic here
        // For example:
        // $cartItems = Cart::all();
        // $total = $cartItems->sum('product_qty * product_price');
        // return view('cart.checkout', compact('cartItems', 'total'));
        return view('cart.checkout');
    }
}