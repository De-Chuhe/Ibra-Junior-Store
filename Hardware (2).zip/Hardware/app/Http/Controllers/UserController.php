<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function index()
        {
            $users = User::paginate(5);
            return view('users.index', ['users'=> $users]);
        }
    // Display the form to create a new user
    public function create()
    {
        return view('users.create'); // Make sure this view exists
    }

    // Store a new user
    public function store(Request $request)
    {
       // $users = User::create($request->all());

        $users = new User;
        $users->name = $request->name;
        $users-> email = $request->email;
        $users->password = md5($request->password);
        $users->is_admin = $request->is_admin;
        $users->save(); 

        if ($users){
            return redirect()->back()->with('user created successfully');
        }
            return redirect()->back()->with('user creation failed');
       //$request->validate([
           // 'name' => 'required|string|max:255',
           // 'email' => 'required|email|unique:users,email',
            //'password' => 'required|string|min:8|confirmed',
           // 'is_admin' => 'required|integer',
       // ]);       

        // Redirect back with a success message
       // return redirect()->route('users.index')->with('success', 'User added successfully.');
    }

    // Update an existing user
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'password' => 'nullable|string|min:8|confirmed',
            'is_admin' => 'required|integer',
        ]);

        $user = User::findOrFail($id);
        $user->name = $request->name;
        $user->email = $request->email;
        if ($request->filled('password')) {
            $user->password = bcrypt($request->password);
        }
        $user->is_admin = $request->is_admin;
        $user->save();

        return redirect()->route('users.index'); // Adjust according to your routes
    }
    //deleting users
    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->route('users.index')->with('success', 'User deleted successfully.');
    }
}
