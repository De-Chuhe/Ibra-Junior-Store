<nav class="active" id="sidebar">
    <ul class="list-unstyled lead">
        <li class="active">
            <a href="<?php echo e(route('home')); ?>"><i class="fa fa-home fa-lg"></i> Home</a>
        </li>
        <li>
            <a href="<?php echo e(route('orders.index')); ?>"><i class="fa fa-box fa-lg"></i> Orders</a>
        </li>
        <li>
            <a href="<?php echo e(route('transactions.index')); ?>"><i class="fa fa-money-bill fa-lg"></i> Transactions</a>
        </li>
        <li>
            <a href="<?php echo e(route('products.index')); ?>"><i class="fa fa-truck fa-lg"></i> Products</a>
        </li>
    </ul>
</nav>

<style>
    #sidebar {
    background: #f8f9fa;
    border-right: 1px solid #dee2e6;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    overflow-y: auto;
}

#sidebar ul.lead {
    border-bottom: 1px solid #47748b;
    list-style-type: none;
    padding-left: 0; /* Remove default padding */
}

#sidebar ul li a {
    display: block;
    padding: 10px 15px; /* Adjust padding for better spacing */
    font-size: 1.1em;
    color: #008B8B;
    text-decoration: none;
}

#sidebar ul li a:hover {
    background-color: #008B8B;
    color: #fff;
}

#sidebar ul li a i {
    margin-right: 10px; /* Adjust icon margin */
}

</style><?php /**PATH C:\Users\Sir Martin Njoroge\Desktop\laravel\resources\views\layouts\includes\sideBar.blade.php ENDPATH**/ ?>