<a href="#" data-toggle="modal" data-target="#exampleModal"class=" btn btn-outline rounded-pill"> <i class="fa fa-list"></i></a>
<a href="<?php echo e(route('users.index')); ?>" class=" btn btn-outline rounded-pill"> <i class="fa fa-users"></i>Users</a>
<a href="<?php echo e(route('products.index')); ?>" class=" btn btn-outline rounded-pill"> <i class="fa fa-box"></i>Products</a>
<a href="<?php echo e(route('orders.index')); ?>" class=" btn btn-outline rounded-pill"> <i class="fa fa-laptop"></i>Cashier</a>
<a href="#" class=" btn btn-outline rounded-pill"> <i class="fa fa-file"></i>Reports</a>
<a href="#" class=" btn btn-outline rounded-pill"> <i class="fa fa-money-bill"></i>Transactions</a>
<a href="#" class=" btn btn-outline rounded-pill"> <i class="fa fa-pie-chart"></i>Suppliers</a>
<a href="#" class=" btn btn-outline rounded-pill"> <i class="fa fa-users"></i>Customers</a>
<a href="#" class=" btn btn-outline rounded-pill"> <i class="fa fa-truck-moving"></i>Incoming</a>


<style>
    .btn-outline {
        border-color: #008B8B;
        color: #008B8B;
    }

    .btn-outline:hover {
        background: #008B8B;
        color: #fff;
    }


</style>
<?php /**PATH C:\Users\Sir Martin Njoroge\Desktop\laravel\resources\views/layouts/includes/navBar.blade.php ENDPATH**/ ?>