<?php $__env->startSection('content'); ?>
<div class="container">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('orders')->html();
} elseif ($_instance->childHasBeenRendered('NUY3xCE')) {
    $componentId = $_instance->getRenderedChildComponentId('NUY3xCE');
    $componentTag = $_instance->getRenderedChildComponentTagName('NUY3xCE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NUY3xCE');
} else {
    $response = \Livewire\Livewire::mount('orders');
    $html = $response->html();
    $_instance->logRenderedChild('NUY3xCE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="modal">
        <div id="print">
            <?php echo $__env->make('Reports.receipt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <style>
        .modal.right .modal-dialog {
            top: 0;
            right: 0;
            margin-right: 15vh;
        }
        .modal.fade:not(.in).right .modal-dialog {
            -webkit-transform: translate3d(25%, 0, 0);
            transform: translate3d(25%, 0, 0);
        }
        .radio-container {
            display: flex;
            align-items: center;
        }
        .radio-item {
            display: flex;
            align-items: center;
            margin-right: 10px;
        }
        .radio-item input[type="radio"] {
            visibility: visible;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        .radio-item input[type="radio"] + label {
            position: relative;
            padding-left: 25px;
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function(){
    $('.add_more').on('click', function(){
        var product = $('.product_id').html();
        var numberofrow = ($('.addMoreProduct tr').length - 0) + 1;
        var tr = '<tr><td class="no">' + numberofrow + '</td>' +
                 '<td><select class="form-control product_id" name="product_id[]">' + product + '</select></td>' +
                 '<td><input type="number" name="quantity[]" class="form-control quantity"></td>' +
                 '<td><input type="number" name="price[]" class="form-control price" readonly></td>' +
                 '<td><input type="number" name="discount[]" class="form-control discount"></td>' +
                 '<td><input type="number" name="total_amount[]" class="form-control total_amount" readonly></td>' +
                 '<td><a class="btn btn-danger btn-sm delete rounded-circle"><i class="fa fa-times"></i></a></td></tr>';
        $('.addMoreProduct').append(tr);
    });

    $(document).on('click', '.delete', function() {
        $(this).parents('tr').remove();
    });

    $('.addMoreProduct').delegate('.product_id', 'change', function(){
        var tr = $(this).parent().parent();
        var price = tr.find('.product_id option:selected').attr('data-price');
        tr.find('.price').val(price);
        var qty = tr.find('.quantity').val() - 0;
        var disc = tr.find('.discount').val() - 0;
        var price = tr.find('.price').val() - 0;
        var total_amount = (qty * price) - ((qty * price * disc) / 100);
        tr.find('.total_amount').val(total_amount);
        total();
    });

    $('.addMoreProduct').delegate('.quantity, .discount', 'keyup', function(){
        var tr = $(this).parent().parent();
        var qty = tr.find('.quantity').val() - 0;
        var disc = tr.find('.discount').val() - 0;
        var price = tr.find('.price').val() - 0;
        var total_amount = (qty * price) - ((qty * price * disc) / 100);
        tr.find('.total_amount').val(total_amount);
        total();
    });

    function total() {
        var total = 0;
        $('.total_amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            total += amount;
        });

        $('.total').html(total);
    }

    $('#paid_amount').keyup(function() {
        var total = $('.total').html();
        var paid_amount = $(this).val();
        var tot = paid_amount - total;
        $('#balance').val(tot).toFixed(2);
    });

    window.PrintReceiptContent = function(el) {
        var data = '<input type="button" id="printPageButton" class="printPageButton" style="display:block;' +
                    'width:100%; border:none; background-color:#008B8B; color:#fff;' +
                    'padding:14px 28px; font-size:16px; cursor:pointer; text-align:center;"' +
                    'value="Print Receipt" onclick="window.print()">';

        data += document.getElementById(el).innerHTML;
        var myReceipt = window.open("", "myWin", "left=150, top=130, width=400, height=400");
        myReceipt.document.write(data);
        myReceipt.document.title = "Print Receipt";
        myReceipt.focus();
        setTimeout(function() {
            myReceipt.print();
            myReceipt.close();
        }, 8000);
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\Hardware\resources\views/orders/index.blade.php ENDPATH**/ ?>