<?php

use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/users',[App\Http\Controllers\UserController::class, 'index'])->name('users.index');
Route::post('/users',[App\Http\Controllers\UserController::class, 'store'])->name('users.store');
// Route for updating a user
Route::put('/users/{id}', [App\Http\Controllers\UserController::class, 'update'])->name('users.update');
//route for deleting a user
Route::delete('users/{user}',[App\Http\Controllers\UserController::class, 'destroy'])->name('users.destroy');

Route::get('/products',[App\Http\Controllers\ProductController::class,'index'])->name('products.index');
Route::post('/products',[App\Http\Controllers\ProductController::class, 'store'])->name('products.store');
// Route for updating a user
Route::put('/products/{id}', [App\Http\Controllers\ProductController::class, 'update'])->name('products.update');
//route for deleting a product
Route::delete('products/{product}',[App\Http\Controllers\ProductController::class, 'destroy'])->name('products.destroy');

// routes/web.php
use App\Http\Controllers\OrderController;
use App\Http\Controllers\OrdersController;

Route::get('/orders', [App\Http\Controllers\OrderController::class, 'index'])->name('orders.index');
Route::post('/orders', [App\Http\Controllers\OrderController::class, 'store'])->name('orders.store');
Route::get('/orders/{id}', [App\Http\Controllers\OrderController::class, 'show'])->name('orders.show');
Route::get('/transactions', [App\Http\Controllers\OrderController::class, 'index'])->name('transactions.index');

// CART

Route::put('/cart/update/{id}', [CartController::class, 'update'])->name('cart.update');
Route::post('/orders/store', [OrderController::class, 'store'])->name('orders.store');
Route::delete('/cart/delete/{id}', [CartController::class, 'delete'])->name('cart.delete');
Route::get('/cart/checkout', [CartController::class, 'checkout'])->name('cart.checkout');




Route::resource('/suppliers','SupplierController'); //suppliers.index
Route::resource('/companies','CompanyController'); //companies.index
Route::resource('/transactions','TransactionController'); //transactions.index



