@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Your Shopping Cart</h2>

    <!-- Cart Items Display -->
    @if(count($cartItems) > 0)
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $grandTotal = 0;
                @endphp
                @foreach($cartItems as $item)
                    @php
                        $totalPrice = $item->product_qty * $item->product_price;
                        $grandTotal += $totalPrice;
                    @endphp
                    <tr>
                        <td>{{ $item->product->product_name }}</td>
                        <td>{{ $item->product_qty }}</td>
                        <td>${{ number_format($item->product_price, 2) }}</td>
                        <td>${{ number_format($totalPrice, 2) }}</td>
                        <td>
                            <!-- Action buttons to update or remove items -->
                            <form action="{{ route('cart.update', $item->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('PUT')
                                <input type="number" name="quantity" value="{{ $item->product_qty }}" min="1" style="width: 60px;">
                                <button type="submit" class="btn btn-sm btn-primary">Update</button>
                            </form>
                            <form action="{{ route('cart.delete', $item->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger">Remove</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                <tr>
                    <td colspan="3" class="text-right"><strong>Grand Total</strong></td>
                    <td><strong>${{ number_format($grandTotal, 2) }}</strong></td>
                    <td></td>
                </tr>
            </tbody>
        </table>

        <!-- Checkout and Print Buttons -->
        <div class="text-right">
            <a href="{{ route('cart.checkout') }}" class="btn btn-success">Checkout</a>
            <button onclick="window.print()" class="btn btn-primary">Print</button>
        </div>
    @else
        <p>Your cart is empty!</p>
    @endif
</div>
@endsection
<style>
    @media print {
        .btn {
            display: none;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
        }
    }
</style>

