
<div id="printed_content">
    <center id="Logo">
        <div class="logo"></div>
        <div class="info"></div>
        <h2>Ibra Stores Hardware</h2>
    </center>
</div>

<div class="mid">
    <div class="info">
        <h2>Contact Us</h2>
        <p>
            Address: KAJIADO: KISERIAN  <br>
            Phone: 0799479881 <br>
        </p>
    </div>
</div>
<div class="bot">
    <div id="table">
        <table>
            <tr class="tabletitle">
                <td class="item"><h2>Item</h2></td>
                <td class="Hours"><h2>Quantity</h2></td>
                <td class="Rate"><h2>Price</h2></td>
                <td class="Rate"><h2>Discount</h2></td>
                <td class="Rate"><h2>Sub Total</h2></td>
            </tr>
            @if ($order_receipt && (is_array($order_receipt) || is_object($order_receipt)))
                @foreach ($order_receipt as $receipt)
                    <tr class="services">
                        <td class="tableitem"><p class="itemtext">{{ $receipt->products->product_name }}</p></td>
                        <td class="tableitem"><p class="itemtext">{{ number_format($receipt->unitprice, 2) }}</p></td>
                        <td class="tableitem"><p class="itemtext">{{ $receipt->quantity }}</p></td>
                        <td class="tableitem"><p class="itemtext">{{ $receipt->discount ? '' : '0' }}</p></td>
                        <td class="tableitem"><p class="itemtext">{{ number_format($receipt->amount, 2) }}</p></td>
                    </tr>
                @endforeach
                <tr class="tabletitle">
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="Rate"><p class="itemtext">Tax</p></td>
                    <td class="Payment"><p class="itemtext">Sub Total $ {{ number_format($order_receipt->sum('amount'), 2) }}</p></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="Rate">Total</td>
                    <td class="Payment"><h2>$ 100</h2></td>
                </tr>
            @else
                <p></p>
            @endif
        </table>
        <div class="legalcopy">
            <p class="legal"><strong>** Thank You For Visiting **</strong><br>
                The Goods Which Are Subjected To Tax, Prices Includes Tax
            </p>
        </div>
        <div class="serialnumber">
            Serial: <span class="Serial-number">12345678</span>
            <span> 4/08/2024 &nbsp; &nbsp; 00:45</span>
        </div>
    </div>
</div>

