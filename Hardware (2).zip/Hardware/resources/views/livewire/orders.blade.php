<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h4 style="float:left">Order Products</h4>
                <a href="#" style="float:right" class="btn btn-dark" data-toggle="modal" data-target="#addproduct">
                    <i class="fa fa-plus"></i> Cart
                </a>
            </div>
            <form action="{{ route('orders.store') }}" method="post">
                @csrf
                <div class="card-body">
                    <div class="my-2">
                        <input type="text" name="product_code" wire:model="product_code" id="" class="form-control" placeholder="Enter Product Code">
                        <button type="submit" wire:click="Inserttocart" class="btn btn-primary mt-2">Add to Cart</button>
                    </div>
                    @if (session()->has('message'))
                        <div class="alert alert-success">{{ session('message') }}</div>
                    @endif
                    @if ($productInCart->isNotEmpty())
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Product Code</th>
                                    <th>Product Name</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th>Disc %</th>
                                    <th>Total</th>
                                    <th><a href="#" class="btn btn-sm btn-success add_more rounded-circle"><i class="fa fa-plus"></i></a></th>
                                </tr>
                            </thead>
                            <tbody class="addMoreProduct">
                                @foreach ($productInCart as $key => $cart)
                                    <tr>
                                        <td class="no">{{ $key + 1 }}</td>
                                        <td width = "30%">
                                            <input type="text" value="{{ $cart->product->product_name ?? 'Unknown Product' }}" id="" name="product_name[]" class="form-control" readonly>
                                        </td>
                                        <td>
                                            <input type="number" name="quantity[]" class="form-control quantity" value="{{ $cart->product_qty }}">
                                        </td>
                                        <td>
                                            <input type="number" name="price[]" class="form-control price" value="{{ $cart->product_price }}" readonly>
                                        </td>
                                        <td>
                                            <input type="number" name="discount[]" class="form-control discount">
                                        </td>
                                        <td>
                                            <input type="number" name="total_amount[]" class="form-control total_amount" value="{{ $cart->product_qty * $cart->product_price }}" readonly>
                                        </td>
                                        <td><a href="#" class="btn btn-sm btn-danger delete rounded-circle"><i class="fa fa-times"></i></a></td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <p>No products in cart.</p>
                    @endif
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-lg btn-block mt-3">Save</button>
                </div>
            </form>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h4>Total <b class="total">0.00</b></h4>
            </div>
            <div class="card-body">
                <div class="btn-group">
                    <button type="button" onclick="printReceipt()" class="btn btn-dark"><i class="fa fa-print"></i> Print</button>
                    <button type="button" class="btn btn-primary"><i class="fa fa-history"></i> History</button>
                    <button type="button" class="btn btn-danger"><i class="fa fa-file-alt"></i> Report</button>
                </div>
                <div class="panel">
                    <div class="row">
                        <table class="table table-striped">
                            <tr>
                                <td>
                                    <label for="">Customer Name</label>
                                    <input type="text" name="customer_name" class="form-control">
                                </td>
                                <td>
                                    <label for="">Customer Number</label>
                                    <input type="number" name="customer_number" class="form-control">
                                </td>
                            </tr>
                        </table>
                        <td>Payment Method <br>
                            <span class="radio-item">
                                <input type="radio" name="payment_method" value="cash" checked="checked">
                                <label><i class="fas fa-money-bill-alt text-success"></i>Cash</label>
                            </span>
                            <span class="radio-item">
                                <input type="radio" name="payment_method" value="mpesa">
                                <label><i class="fas fa-mobile text-info"></i>M-PESA</label>
                            </span>
                            <span class="radio-item">
                                <input type="radio" name="payment_method" value="bank_transfer">
                                <label><i class="fas fa-university text-info"></i>Bank Transfer</label>
                            </span>
                        </td><br>
                        <td>
                            Payment
                            <input type="number" name="paid_amount" id="paid_amount" class="form-control">
                        </td>
                        <td>
                            Returning change
                            <input type="number" readonly name="balance" id="balance" class="form-control">
                        </td>
                        <td>
                            <button type="submit" class="btn-primary btn-lg btn-block mt-3">Save</button>
                        </td>
                        <td>
                            <button class="btn-danger btn-lg btn-block mt-2">Calculator</button>
                        </td>
                        <td>
                            <a href="#" style="text-align:center !important" class="text-danger"><i class="fa fa-sign-out-alt"></i> Log out</a>
                        </td>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Cart Modal -->
    <div class="modal right fade" id="addproduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="exampleModalLabel">Cart</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('products.store') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="name">Product Name</label>
                            <input type="text" name="product_name" id="name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="brand">Quantity</label>
                            <input type="text" name="brand" id="brand" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="price">Price</label>
                            <input type="number" name="price" id="price" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="alert_stock">Discount</label>
                            <input type="number" name="alert_stock" id="alert_stock" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="quantity">Total</label>
                            <input type="number" name="quantity" id="quantity" class="form-control">
                        </div>
                       
                        <div class="modal-footer justify-content-center">
                            <button type="submit" class="btn btn-primary btn-block">Check Out</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
